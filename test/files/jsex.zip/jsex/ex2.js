require("./procarv.js")

console.log("Help I'm Alive")
