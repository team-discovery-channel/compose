console.log(process.argv)
