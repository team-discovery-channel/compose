exports.module2_function = function(){
    var x = 2;
    return x;
}