exports.module1_function = function(){
    var x = 1;
    return x;
}