var run = function(value){
    value[0] += 1;
}

exports.run = run;